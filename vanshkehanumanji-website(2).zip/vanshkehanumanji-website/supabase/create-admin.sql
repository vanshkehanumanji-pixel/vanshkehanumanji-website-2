-- Run AFTER schema.sql and AFTER creating your user in Authentication -> Users.
-- Replace the email below with YOUR email (the same one you used for the user), then press Run.
insert into public.admins (user_id)
select id from auth.users where email = 'YOUR-EMAIL@example.com';
