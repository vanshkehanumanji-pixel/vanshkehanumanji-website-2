-- =====================================================================
-- VanshkeHanumanji Team — Supabase schema, security policies and storage
-- Run this ONCE in: Supabase Dashboard -> SQL Editor -> New query -> Run.
-- Safe to re-run (uses IF NOT EXISTS / DROP POLICY IF EXISTS).
-- =====================================================================

-- ---------- admins ----------
-- Anyone listed here is a website administrator. Rows are added ONLY from the
-- SQL editor (see README "Admin account setup"); there is no public way to add one.
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

-- ---------- content tables ----------
create table if not exists public.site_content (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.team_members (
  id uuid primary key default gen_random_uuid(),
  category text not null check (category in ('core','main','member','volunteer')),
  name text not null,
  designation text,
  city text,
  description text,
  photo_url text,
  sort_order int not null default 0,
  published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.seva_activities (
  id uuid primary key default gen_random_uuid(),
  category text not null check (category in ('social','religious','awareness','community','welfare')),
  title text not null,
  title_hi text,
  description text,
  description_hi text,
  photo_url text,
  activity_date date,
  location text,
  sort_order int not null default 0,
  published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.gallery_items (
  id uuid primary key default gen_random_uuid(),
  section text not null check (section in ('team','social','religious','campaign','community')),
  media_type text not null default 'image' check (media_type in ('image','video')),
  url text not null,
  caption text,
  caption_hi text,
  sort_order int not null default 0,
  published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  kind text not null default 'announcement' check (kind in ('announcement','notice','event','update')),
  title text not null,
  title_hi text,
  body text,
  body_hi text,
  event_date date,
  published_at timestamptz not null default now(),
  published boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------- private tables (public can only INSERT) ----------
create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  mobile text not null,
  whatsapp text not null,
  city text not null,
  state text not null,
  age int not null,
  instagram text,
  occupation text not null,
  reason text not null,
  experience text,
  consent boolean not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  phone text,
  message text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- Row Level Security ----------
alter table public.admins            enable row level security;
alter table public.site_content      enable row level security;
alter table public.team_members      enable row level security;
alter table public.seva_activities   enable row level security;
alter table public.gallery_items     enable row level security;
alter table public.announcements     enable row level security;
alter table public.applications      enable row level security;
alter table public.contact_messages  enable row level security;

-- admins: a signed-in user may read only their OWN row (so the app can tell if
-- they are an admin). Nobody can insert/update/delete through the API.
drop policy if exists "admins read own row" on public.admins;
create policy "admins read own row" on public.admins
  for select to authenticated using (user_id = auth.uid());

-- site_content: public read, admin write
drop policy if exists "public read content" on public.site_content;
create policy "public read content" on public.site_content for select to anon, authenticated using (true);
drop policy if exists "admin write content" on public.site_content;
create policy "admin write content" on public.site_content for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- published-only public read + admin full access, for the four public collections
do $$
declare t text;
begin
  foreach t in array array['team_members','seva_activities','gallery_items','announcements']
  loop
    execute format('drop policy if exists "public read published" on public.%I', t);
    execute format('create policy "public read published" on public.%I for select to anon, authenticated using (published = true)', t);
    execute format('drop policy if exists "admin all" on public.%I', t);
    execute format('create policy "admin all" on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())', t);
  end loop;
end $$;

-- applications: anyone may submit (validated), only admins may read / change / delete
drop policy if exists "public submit application" on public.applications;
create policy "public submit application" on public.applications
  for insert to anon, authenticated
  with check (
    status = 'pending'
    and consent = true
    and char_length(full_name) between 2 and 100
    and char_length(reason) between 1 and 2000
    and coalesce(char_length(experience), 0) <= 2000
    and age between 13 and 100
  );
drop policy if exists "admin all" on public.applications;
create policy "admin all" on public.applications for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- contact_messages: same pattern
drop policy if exists "public send message" on public.contact_messages;
create policy "public send message" on public.contact_messages
  for insert to anon, authenticated
  with check (
    is_read = false
    and char_length(name) between 2 and 100
    and char_length(message) between 5 and 3000
    and email ~* '^\S+@\S+\.\S+$'
  );
drop policy if exists "admin all" on public.contact_messages;
create policy "admin all" on public.contact_messages for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------- storage: one public-read bucket, admin-only writes ----------
insert into storage.buckets (id, name, public, file_size_limit)
values ('media', 'media', true, 52428800)
on conflict (id) do nothing;

drop policy if exists "public read media" on storage.objects;
create policy "public read media" on storage.objects for select using (bucket_id = 'media');
drop policy if exists "admin upload media" on storage.objects;
create policy "admin upload media" on storage.objects for insert to authenticated
  with check (bucket_id = 'media' and public.is_admin());
drop policy if exists "admin update media" on storage.objects;
create policy "admin update media" on storage.objects for update to authenticated
  using (bucket_id = 'media' and public.is_admin());
drop policy if exists "admin delete media" on storage.objects;
create policy "admin delete media" on storage.objects for delete to authenticated
  using (bucket_id = 'media' and public.is_admin());

-- =====================================================================
-- AFTER running this file, create the owner admin (see README step "Admin account setup"):
--   1. Authentication -> Users -> Add user -> enter YOUR email + a strong password.
--   2. Run this in the SQL editor (replace the email):
--        insert into public.admins (user_id)
--        select id from auth.users where email = 'your-email@example.com';
--   3. Authentication -> Sign In / Providers -> turn OFF "Allow new users to sign up".
-- =====================================================================
