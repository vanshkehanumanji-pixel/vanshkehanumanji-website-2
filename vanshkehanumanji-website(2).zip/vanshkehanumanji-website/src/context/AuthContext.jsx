import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { supabase, isConfigured } from '../lib/supabase'

const AuthCtx = createContext(null)

// Auth is handled entirely by Supabase Auth. "Admin" means the signed-in user's id
// exists in the `admins` table (see supabase/schema.sql). Real enforcement happens
// in the database (Row Level Security); this flag only controls what the UI shows.
export function AuthProvider({ children }) {
  const [session, setSession] = useState(null)
  const [ready, setReady] = useState(!isConfigured)
  const [isAdmin, setIsAdmin] = useState(false)
  const [checking, setChecking] = useState(false)

  useEffect(() => {
    if (!isConfigured) return undefined
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setReady(true)
    })
    const { data } = supabase.auth.onAuthStateChange((_event, s) => setSession(s))
    return () => data.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (!isConfigured || !ready) return undefined
    if (!session) {
      setIsAdmin(false)
      setChecking(false)
      return undefined
    }
    let off = false
    setChecking(true)
    supabase
      .from('admins')
      .select('user_id')
      .eq('user_id', session.user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (!off) {
          setIsAdmin(Boolean(data))
          setChecking(false)
        }
      })
    return () => {
      off = true
    }
  }, [session, ready])

  const signIn = useCallback(
    (email, password) => supabase.auth.signInWithPassword({ email, password }),
    []
  )
  const signOut = useCallback(() => supabase.auth.signOut(), [])

  const value = useMemo(
    () => ({ session, isAdmin, loading: !ready || checking, signIn, signOut }),
    [session, isAdmin, ready, checking, signIn, signOut]
  )
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>
}

export const useAuth = () => useContext(AuthCtx)
