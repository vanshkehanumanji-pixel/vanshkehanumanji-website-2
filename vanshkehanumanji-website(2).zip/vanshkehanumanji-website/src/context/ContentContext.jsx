import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { supabase, isConfigured } from '../lib/supabase'
import { defaults } from '../lib/defaults'
import { deepMerge } from '../lib/utils'

const ContentCtx = createContext(null)

// Default content merged with anything the founder has edited in the dashboard.
export function ContentProvider({ children }) {
  const [stored, setStored] = useState({})

  const reload = useCallback(async () => {
    if (!isConfigured) return
    const { data } = await supabase.from('site_content').select('key,value')
    if (data) setStored(Object.fromEntries(data.map((r) => [r.key, r.value])))
  }, [])

  useEffect(() => {
    reload()
  }, [reload])

  const content = useMemo(() => {
    const out = {}
    for (const k of Object.keys(defaults)) out[k] = deepMerge(defaults[k], stored[k])
    return out
  }, [stored])

  const value = useMemo(() => ({ content, reload }), [content, reload])
  return <ContentCtx.Provider value={value}>{children}</ContentCtx.Provider>
}

export const useContent = () => useContext(ContentCtx)
