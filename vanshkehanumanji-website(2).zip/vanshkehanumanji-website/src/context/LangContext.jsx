import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { ui } from '../lib/ui'

const LangCtx = createContext(null)

export function LangProvider({ children }) {
  const [lang, setLang] = useState(() => {
    try {
      return localStorage.getItem('lang') === 'en' ? 'en' : 'hi'
    } catch {
      return 'hi'
    }
  })

  useEffect(() => {
    document.documentElement.lang = lang
    try {
      localStorage.setItem('lang', lang)
    } catch {
      /* storage can be blocked; language still works for this visit */
    }
  }, [lang])

  // t('nav.home') -> interface string
  const t = useCallback((key) => ui[key]?.[lang] ?? ui[key]?.en ?? key, [lang])
  // tx({en, hi}) -> content string (plain strings pass through)
  const tx = useCallback(
    (v) => (v && typeof v === 'object' ? v[lang] || v.en || v.hi || '' : v ?? ''),
    [lang]
  )
  const toggle = useCallback(() => setLang((l) => (l === 'hi' ? 'en' : 'hi')), [])

  const value = useMemo(() => ({ lang, t, tx, toggle }), [lang, t, tx, toggle])
  return <LangCtx.Provider value={value}>{children}</LangCtx.Provider>
}

export const useLang = () => useContext(LangCtx)
