import { useLang } from '../context/LangContext'
import { useContent } from '../context/ContentContext'
import { useMeta } from '../lib/useMeta'
import { PageBanner, SectionHeading } from '../components/ui'

export default function About() {
  const { t, tx } = useLang()
  const { content } = useContent()
  const { about, home } = content
  useMeta(t('nav.about'), t('about.metaDesc'))

  return (
    <>
      <PageBanner eyebrow={t('about.eyebrow')} title={t('about.title')}>
        {tx(content.site.tagline)}
      </PageBanner>

      <section className="section section--ivory">
        <div className="container split">
          <div>
            <SectionHeading eyebrow={t('about.who')} title={t('about.who')} />
            <p>{tx(home.who)}</p>
          </div>
          <div>
            <SectionHeading eyebrow={t('about.story')} title={t('about.story')} />
            <p>{tx(about.story)}</p>
          </div>
        </div>
      </section>

      <section className="section section--maroon">
        <div className="container split">
          <div>
            <span className="eyebrow">{t('about.mission')}</span>
            <h2>{t('about.mission')}</h2>
            <div className="quote-panel"><p>{tx(about.mission)}</p></div>
          </div>
          <div>
            <span className="eyebrow">{t('about.vision')}</span>
            <h2>{t('about.vision')}</h2>
            <div className="quote-panel"><p>{tx(about.vision)}</p></div>
          </div>
        </div>
      </section>

      <section className="section section--sand">
        <div className="container">
          <SectionHeading eyebrow={t('about.values')} title={t('about.values')} center />
          <ol className="value-list" style={{ maxWidth: 820, marginInline: 'auto' }}>
            {about.values.map((v, i) => (
              <li key={i}>{tx(v)}</li>
            ))}
          </ol>
        </div>
      </section>

      <section className="section section--ivory">
        <div className="container grid grid--2">
          <article className="card">
            <h3>{t('about.purpose')}</h3>
            <p style={{ marginBottom: 0 }}>{tx(about.purpose)}</p>
          </article>
          <article className="card">
            <h3>{t('about.commitment')}</h3>
            <p style={{ marginBottom: 0 }}>{tx(about.commitment)}</p>
          </article>
        </div>
      </section>
    </>
  )
}
