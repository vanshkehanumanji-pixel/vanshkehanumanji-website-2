import { useMemo, useState } from 'react'
import { useLang } from '../context/LangContext'
import { useCollection } from '../lib/useCollection'
import { useMeta } from '../lib/useMeta'
import { GALLERY_SECTIONS } from '../lib/defaults'
import { youtubeEmbed, pick } from '../lib/utils'
import { PageBanner, EmptyState } from '../components/ui'
import { GalleryTile } from '../components/cards'
import Lightbox from '../components/Lightbox'

export default function Gallery() {
  const { t, lang } = useLang()
  useMeta(t('nav.gallery'), t('gallery.metaDesc'))
  const { rows, loading } = useCollection('gallery_items', { order: 'sort_order', asc: true })
  const [section, setSection] = useState('all')
  const [lb, setLb] = useState(null)

  const inSection = useMemo(
    () => (section === 'all' ? rows : rows.filter((r) => r.section === section)),
    [rows, section]
  )
  const images = inSection.filter((r) => r.media_type !== 'video')
  const videos = inSection.filter((r) => r.media_type === 'video')

  return (
    <>
      <PageBanner eyebrow={t('gallery.eyebrow')} title={t('gallery.title')} />
      <section className="section section--ivory">
        <div className="container">
          <div className="chips" role="group" aria-label="Sections">
            <button type="button" className="chip" aria-pressed={section === 'all'} onClick={() => setSection('all')}>
              {t('seva.all')}
            </button>
            {GALLERY_SECTIONS.map((s) => (
              <button key={s.id} type="button" className="chip" aria-pressed={section === s.id} onClick={() => setSection(s.id)}>
                {s[lang]}
              </button>
            ))}
          </div>

          {loading ? (
            <p className="muted">{t('common.loading')}</p>
          ) : !inSection.length ? (
            <EmptyState title={t('gallery.soon')} text={t('gallery.soonText')} />
          ) : (
            <>
              {images.length > 0 && (
                <>
                  <h2 style={{ fontSize: '1.8rem' }}>{t('gallery.photos')}</h2>
                  <div className="gallery-grid" style={{ marginBottom: 56 }}>
                    {images.map((r, i) => (
                      <GalleryTile key={r.id} item={r} onOpen={() => setLb(i)} />
                    ))}
                  </div>
                </>
              )}
              {videos.length > 0 && (
                <>
                  <h2 style={{ fontSize: '1.8rem' }}>{t('gallery.videos')}</h2>
                  <div className="grid grid--2">
                    {videos.map((v) => {
                      const embed = youtubeEmbed(v.url)
                      const cap = pick(v, 'caption', lang)
                      return (
                        <figure key={v.id} style={{ margin: 0 }}>
                          <div className="video-box">
                            {embed ? (
                              <iframe src={embed} title={cap || 'Video'} loading="lazy" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" />
                            ) : (
                              <video src={v.url} controls preload="metadata" />
                            )}
                          </div>
                          {cap && <figcaption style={{ marginTop: 8 }}>{cap}</figcaption>}
                        </figure>
                      )
                    })}
                  </div>
                </>
              )}
            </>
          )}
        </div>
        {lb !== null && <Lightbox items={images} index={lb} onChange={setLb} onClose={() => setLb(null)} />}
      </section>
    </>
  )
}
