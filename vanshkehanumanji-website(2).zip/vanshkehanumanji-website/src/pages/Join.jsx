import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useLang } from '../context/LangContext'
import { useContent } from '../context/ContentContext'
import { useMeta } from '../lib/useMeta'
import { supabase, isConfigured } from '../lib/supabase'
import { cleanPhone, isIndianMobile } from '../lib/utils'
import { PageBanner, Field } from '../components/ui'

const empty = {
  full_name: '', mobile: '', whatsapp: '', city: '', state: '', age: '',
  instagram: '', occupation: '', reason: '', experience: '', consent: false, website: '',
}

export default function Join() {
  const { t } = useLang()
  const { content } = useContent()
  useMeta(t('nav.join'), t('join.metaDesc'))

  const [form, setForm] = useState(empty)
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState('idle') // idle | sending | ok | error

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }))

  function validate() {
    const e = {}
    const req = t('err.required')
    if (form.full_name.trim().length < 2) e.full_name = req
    if (!isIndianMobile(form.mobile)) e.mobile = t('err.mobile')
    if (!isIndianMobile(form.whatsapp)) e.whatsapp = t('err.mobile')
    if (!form.city.trim()) e.city = req
    if (!form.state.trim()) e.state = req
    const age = Number(form.age)
    if (!form.age || !Number.isInteger(age) || age < 13 || age > 100) e.age = t('err.age')
    if (!form.occupation.trim()) e.occupation = req
    if (!form.reason.trim()) e.reason = req
    else if (form.reason.trim().length < 20) e.reason = t('err.reasonShort')
    if (!form.consent) e.consent = t('err.consent')
    return e
  }

  async function onSubmit(ev) {
    ev.preventDefault()
    if (form.website) return // honeypot: silently ignore bots
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length) {
      setStatus('idle')
      return
    }
    // Never claim success unless the database really accepted the row.
    if (!isConfigured) {
      setStatus('error')
      return
    }
    setStatus('sending')
    const { error } = await supabase.from('applications').insert({
      full_name: form.full_name.trim(),
      mobile: cleanPhone(form.mobile),
      whatsapp: cleanPhone(form.whatsapp),
      city: form.city.trim(),
      state: form.state.trim(),
      age: Number(form.age),
      instagram: form.instagram.trim().replace(/^@/, '') || null,
      occupation: form.occupation.trim(),
      reason: form.reason.trim(),
      experience: form.experience.trim() || null,
      consent: true,
    })
    if (error) {
      setStatus('error')
    } else {
      setStatus('ok')
      setForm(empty)
    }
  }

  const err = (k) => errors[k]
  const common = (k) => ({
    id: k, value: form[k], onChange: set(k), 'aria-invalid': Boolean(err(k)),
    'aria-describedby': err(k) ? `${k}-err` : undefined,
  })

  return (
    <>
      <PageBanner eyebrow={t('join.eyebrow')} title={t('join.title')}>
        {t('join.lead')}
      </PageBanner>
      <section className="section section--sand">
        <div className="container" style={{ maxWidth: 820 }}>
          {!isConfigured && (
            <div className="alert alert--info" role="status" style={{ marginBottom: 24 }}>
              {t('join.notConnected')}{' '}
              {content.contact.whatsappUrl && (
                <a href={content.contact.whatsappUrl} target="_blank" rel="noopener noreferrer" style={{ fontWeight: 600, textDecoration: 'underline' }}>
                  WhatsApp
                </a>
              )}
            </div>
          )}

          {status === 'ok' ? (
            <div className="alert alert--ok" role="status">{t('join.success')}</div>
          ) : (
            <form className="form form-card" onSubmit={onSubmit} noValidate>
              <div className="hp" aria-hidden="true">
                <label>Website <input tabIndex={-1} autoComplete="off" value={form.website} onChange={set('website')} /></label>
              </div>

              <Field id="full_name" label={`${t('join.fullName')} *`} error={err('full_name')}>
                <input type="text" autoComplete="name" maxLength={100} {...common('full_name')} />
              </Field>

              <div className="form__row">
                <Field id="mobile" label={`${t('join.mobile')} *`} error={err('mobile')}>
                  <input type="tel" inputMode="numeric" autoComplete="tel" placeholder="98XXXXXXXX" {...common('mobile')} />
                </Field>
                <Field id="whatsapp" label={`${t('join.whatsapp')} *`} error={err('whatsapp')}>
                  <input type="tel" inputMode="numeric" placeholder="98XXXXXXXX" {...common('whatsapp')} />
                </Field>
              </div>

              <div className="form__row">
                <Field id="city" label={`${t('join.city')} *`} error={err('city')}>
                  <input type="text" autoComplete="address-level2" maxLength={80} {...common('city')} />
                </Field>
                <Field id="state" label={`${t('join.state')} *`} error={err('state')}>
                  <input type="text" autoComplete="address-level1" maxLength={80} {...common('state')} />
                </Field>
              </div>

              <div className="form__row">
                <Field id="age" label={`${t('join.age')} *`} error={err('age')}>
                  <input type="number" inputMode="numeric" min="13" max="100" {...common('age')} />
                </Field>
                <Field id="instagram" label={t('join.instagram')} optional>
                  <input type="text" placeholder="@username" maxLength={60} {...common('instagram')} />
                </Field>
              </div>

              <Field id="occupation" label={`${t('join.occupation')} *`} error={err('occupation')}>
                <input type="text" maxLength={100} {...common('occupation')} />
              </Field>

              <Field id="reason" label={`${t('join.reason')} *`} error={err('reason')}>
                <textarea maxLength={2000} {...common('reason')} />
              </Field>

              <Field id="experience" label={t('join.experience')} optional>
                <textarea maxLength={2000} {...common('experience')} />
              </Field>

              <div className={`field ${err('consent') ? 'invalid' : ''}`}>
                <label className="check" style={{ fontWeight: 400 }}>
                  <input type="checkbox" checked={form.consent} onChange={set('consent')} aria-invalid={Boolean(err('consent'))} />
                  <span>
                    {t('join.consent')} (<Link to="/privacy" style={{ textDecoration: 'underline' }}>{t('footer.privacy')}</Link>)
                  </span>
                </label>
                {err('consent') && <div className="err" role="alert">{err('consent')}</div>}
              </div>

              {Object.keys(errors).length > 0 && <div className="alert alert--err" role="alert">{t('join.fixErrors')}</div>}
              {status === 'error' && <div className="alert alert--err" role="alert">{t('join.error')}</div>}

              <button className="btn btn--saffron" type="submit" disabled={status === 'sending'}>
                {status === 'sending' ? t('join.sending') : t('join.submit')}
              </button>
            </form>
          )}
        </div>
      </section>
    </>
  )
}
