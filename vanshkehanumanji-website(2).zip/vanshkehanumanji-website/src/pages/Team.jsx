import { useLang } from '../context/LangContext'
import { useCollection } from '../lib/useCollection'
import { useMeta } from '../lib/useMeta'
import { TEAM_CATEGORIES } from '../lib/defaults'
import { PageBanner, EmptyState, Img } from '../components/ui'

export default function Team() {
  const { t, lang } = useLang()
  useMeta(t('nav.team'), t('team.metaDesc'))
  const { rows } = useCollection('team_members', { order: 'sort_order', asc: true })

  return (
    <>
      <PageBanner eyebrow={t('team.eyebrow')} title={t('team.title')} />
      <section className="section section--sand">
        <div className="container">
          {TEAM_CATEGORIES.map((cat) => {
            const members = rows.filter((m) => m.category === cat.id)
            return (
              <div className="team-group" key={cat.id}>
                <h3>{cat[lang]}</h3>
                {members.length ? (
                  <div className="grid grid--4">
                    {members.map((m) => (
                      <article className="member" key={m.id}>
                        <div className="member__photo">
                          <Img src={m.photo_url} alt={m.name} />
                        </div>
                        <div className="member__body">
                          <h4 style={{ marginBottom: 4 }}>{m.name}</h4>
                          {m.designation && <div className="member__role">{m.designation}</div>}
                          {m.city && <div className="meta" style={{ justifyContent: 'center' }}>{m.city}</div>}
                          {m.description && <p style={{ fontSize: '0.92rem', marginTop: 10, marginBottom: 0 }}>{m.description}</p>}
                        </div>
                      </article>
                    ))}
                  </div>
                ) : (
                  <EmptyState title={t('team.soon')} text={t('team.soonText')} />
                )}
              </div>
            )
          })}
        </div>
      </section>
    </>
  )
}
