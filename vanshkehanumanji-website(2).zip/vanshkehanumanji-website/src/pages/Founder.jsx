import { Link } from 'react-router-dom'
import { useLang } from '../context/LangContext'
import { useContent } from '../context/ContentContext'
import { useMeta } from '../lib/useMeta'
import { FramedPhoto, SectionHeading } from '../components/ui'
import Icon from '../components/Icon'

export default function Founder() {
  const { t, tx } = useLang()
  const { content } = useContent()
  const { founder, about, contact } = content
  useMeta(t('nav.founder'), t('founder.metaDesc'))

  return (
    <>
      <section className="hero" style={{ paddingBottom: 90 }}>
        <div className="container founder-hero">
          <div className="reveal">
            <FramedPhoto src={founder.photo} alt={tx(founder.name)} />
          </div>
          <div className="reveal" style={{ animationDelay: '0.12s' }}>
            <span className="eyebrow" style={{ color: 'var(--gold)' }}>{t('founder.eyebrow')}</span>
            <h1 className="hero__brand" style={{ fontSize: 'clamp(2.2rem,5vw,3.8rem)' }}>{tx(founder.name)}</h1>
            <p className="hero__headline" style={{ fontSize: '1.4rem' }}>{tx(founder.designation)}</p>
            <p className="hero__sub" style={{ marginTop: 6 }}>
              <Icon name="pin" size={16} /> {tx(founder.location)}
            </p>
            <p className="hero__sub">{tx(founder.intro)}</p>
          </div>
        </div>
      </section>

      <section className="section section--ivory">
        <div className="container">
          <SectionHeading eyebrow={t('founder.message')} title={t('founder.message')} />
          <div className="quote-panel" style={{ maxWidth: 860 }}>
            <p>“{tx(founder.message)}”</p>
            <p style={{ fontSize: '1rem', fontFamily: 'var(--f-body)', color: 'var(--muted)' }}>
              — {tx(founder.name)}, {tx(founder.designation)}
            </p>
          </div>
        </div>
      </section>

      <section className="section section--maroon">
        <div className="container split">
          <div>
            <span className="eyebrow">{t('founder.vision')}</span>
            <h2>{t('founder.vision')}</h2>
            <div className="quote-panel"><p>{tx(about.vision)}</p></div>
          </div>
          <div>
            <span className="eyebrow">{t('founder.mission')}</span>
            <h2>{t('founder.mission')}</h2>
            <div className="quote-panel"><p>{tx(about.mission)}</p></div>
          </div>
        </div>
      </section>

      <section className="section section--sand">
        <div className="container">
          <SectionHeading eyebrow={t('founder.social')} title={t('founder.social')} />
          <div className="social">
            {contact.instagramUrl && (
              <a href={contact.instagramUrl} target="_blank" rel="noopener noreferrer">
                <Icon name="instagram" size={18} /> {contact.instagram || 'Instagram'}
              </a>
            )}
            {contact.whatsappUrl && (
              <a href={contact.whatsappUrl} target="_blank" rel="noopener noreferrer">
                <Icon name="whatsapp" size={18} /> WhatsApp
              </a>
            )}
            {contact.email && (
              <a href={`mailto:${contact.email}`}>
                <Icon name="mail" size={18} /> {contact.email}
              </a>
            )}
            {contact.facebookUrl && (
              <a href={contact.facebookUrl} target="_blank" rel="noopener noreferrer">
                <Icon name="link" size={18} /> Facebook
              </a>
            )}
            {contact.youtubeUrl && (
              <a href={contact.youtubeUrl} target="_blank" rel="noopener noreferrer">
                <Icon name="link" size={18} /> YouTube
              </a>
            )}
          </div>
          <div className="btn-row">
            <Link className="btn btn--dark" to="/contact">{t('nav.contact')}</Link>
          </div>
        </div>
      </section>
    </>
  )
}
