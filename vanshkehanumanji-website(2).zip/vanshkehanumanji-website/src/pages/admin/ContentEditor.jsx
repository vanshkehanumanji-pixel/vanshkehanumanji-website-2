import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useContent } from '../../context/ContentContext'
import { getPath, setPath } from '../../lib/utils'
import FieldInput from './FieldInput'

// Edits one `site_content` row. Starts from the current (default + saved) content.
export default function ContentEditor({ contentKey, title, fields }) {
  const { content, reload } = useContent()
  const [draft, setDraft] = useState(() => structuredClone(content[contentKey]))
  const [state, setState] = useState({ saving: false, msg: '', error: '' })

  useEffect(() => {
    setDraft(structuredClone(content[contentKey]))
  }, [contentKey]) // eslint-disable-line react-hooks/exhaustive-deps

  async function save(e) {
    e.preventDefault()
    setState({ saving: true, msg: '', error: '' })
    const { error } = await supabase
      .from('site_content')
      .upsert({ key: contentKey, value: draft, updated_at: new Date().toISOString() })
    if (error) setState({ saving: false, msg: '', error: error.message })
    else {
      await reload()
      setState({ saving: false, msg: 'Saved. The live website now shows these changes.', error: '' })
    }
  }

  const update = (path, v) => setDraft((d) => setPath(d, path, v))

  return (
    <form className="a-card" onSubmit={save}>
      <h1>{title}</h1>
      {fields.map((f) => {
        const val = getPath(draft, f.path)
        if (f.type === 'bitext' || f.type === 'bitextarea') {
          const inner = f.type === 'bitext' ? 'text' : 'textarea'
          return (
            <fieldset className="a-field a-bi" key={f.path}>
              <legend>{f.label}</legend>
              <label>
                English
                <FieldInput field={{ type: inner, path: `${f.path}.en` }} value={val?.en} onChange={(v) => update(`${f.path}.en`, v)} />
              </label>
              <label>
                हिन्दी
                <FieldInput field={{ type: inner, path: `${f.path}.hi` }} value={val?.hi} onChange={(v) => update(`${f.path}.hi`, v)} />
              </label>
            </fieldset>
          )
        }
        return (
          <div className="a-field" key={f.path}>
            <label htmlFor={`f-${f.path}`}>{f.label}</label>
            <FieldInput field={f} value={val} onChange={(v) => update(f.path, v)} />
          </div>
        )
      })}
      {state.error && <div className="a-error">{state.error}</div>}
      {state.msg && <div className="a-ok">{state.msg}</div>}
      <button className="a-btn" type="submit" disabled={state.saving}>
        {state.saving ? 'Saving…' : 'Save changes'}
      </button>
    </form>
  )
}
