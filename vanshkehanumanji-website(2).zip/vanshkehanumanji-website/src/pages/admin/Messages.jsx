import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'

export default function Messages() {
  const [rows, setRows] = useState([])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    const { data, error: e } = await supabase.from('contact_messages').select('*').order('created_at', { ascending: false })
    if (e) setError(e.message)
    else setRows(data)
    setLoading(false)
  }, [])
  useEffect(() => {
    load()
  }, [load])

  async function toggle(r) {
    const { error: e } = await supabase.from('contact_messages').update({ is_read: !r.is_read }).eq('id', r.id)
    if (e) setError(e.message)
    else load()
  }
  async function remove(r) {
    if (!window.confirm('Delete this message permanently?')) return
    const { error: e } = await supabase.from('contact_messages').delete().eq('id', r.id)
    if (e) setError(e.message)
    else load()
  }

  return (
    <div className="a-card">
      <h1>Contact Messages</h1>
      {error && <div className="a-error">{error}</div>}
      {loading ? (
        <p>Loading…</p>
      ) : !rows.length ? (
        <p className="a-note">No messages yet.</p>
      ) : (
        <ul className="a-list">
          {rows.map((r) => (
            <li key={r.id} className="a-list--col">
              <div className="a-row">
                <div className="a-list__main">
                  <strong>{r.name} {!r.is_read && <span className="a-pill">new</span>}</strong>
                  <span>
                    <a href={`mailto:${r.email}`}>{r.email}</a>{r.phone ? ` · ${r.phone}` : ''} · {new Date(r.created_at).toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="a-actions">
                  <button className="a-btn a-btn--ghost" type="button" onClick={() => toggle(r)}>{r.is_read ? 'Mark unread' : 'Mark read'}</button>
                  <button className="a-btn a-btn--danger" type="button" onClick={() => remove(r)}>Delete</button>
                </div>
              </div>
              <p style={{ whiteSpace: 'pre-line', margin: '10px 0 0' }}>{r.message}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
