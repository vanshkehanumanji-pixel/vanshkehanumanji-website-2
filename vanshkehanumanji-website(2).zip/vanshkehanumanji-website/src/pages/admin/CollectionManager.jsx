import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'
import FieldInput from './FieldInput'

// Generic list + add/edit/delete screen for any content table.
export default function CollectionManager({ config }) {
  const { table, title, fields, blank, orderBy, asc, rowTitle, rowMeta, rowThumb } = config
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(null)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [msg, setMsg] = useState('')

  const load = useCallback(async () => {
    const { data, error: e } = await supabase.from(table).select('*').order(orderBy, { ascending: asc })
    if (e) setError(e.message)
    else setRows(data)
    setLoading(false)
  }, [table, orderBy, asc])

  useEffect(() => {
    load()
  }, [load])

  async function save(e) {
    e.preventDefault()
    setSaving(true)
    setError('')
    setMsg('')
    const payload = {}
    fields.forEach((f) => {
      let v = editing[f.name]
      if (v === '' || v === undefined) v = null
      if (f.type === 'number') v = v === null ? 0 : Number(v)
      payload[f.name] = v
    })
    const q = editing.id
      ? supabase.from(table).update(payload).eq('id', editing.id)
      : supabase.from(table).insert(payload)
    const { error: err } = await q
    setSaving(false)
    if (err) {
      setError(err.message)
      return
    }
    setMsg('Saved.')
    setEditing(null)
    load()
  }

  async function remove(row) {
    if (!window.confirm('Delete this item permanently?')) return
    const { error: err } = await supabase.from(table).delete().eq('id', row.id)
    if (err) setError(err.message)
    else load()
  }

  async function togglePublished(row) {
    const { error: err } = await supabase.from(table).update({ published: !row.published }).eq('id', row.id)
    if (err) setError(err.message)
    else load()
  }

  if (editing) {
    return (
      <form className="a-card" onSubmit={save}>
        <h1>{editing.id ? 'Edit' : 'Add'} — {title}</h1>
        {fields.map((f) => (
          <div className="a-field" key={f.name}>
            <label htmlFor={`f-${f.name}`}>{f.label}</label>
            <FieldInput field={f} value={editing[f.name]} onChange={(v) => setEditing((r) => ({ ...r, [f.name]: v }))} />
          </div>
        ))}
        {error && <div className="a-error">{error}</div>}
        <div className="a-actions">
          <button className="a-btn" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
          <button className="a-btn a-btn--ghost" type="button" onClick={() => { setEditing(null); setError('') }}>Cancel</button>
        </div>
      </form>
    )
  }

  return (
    <div className="a-card">
      <div className="a-head">
        <h1>{title}</h1>
        <button className="a-btn" type="button" onClick={() => { setEditing({ ...blank }); setMsg(''); setError('') }}>
          + Add new
        </button>
      </div>
      {msg && <div className="a-ok">{msg}</div>}
      {error && <div className="a-error">{error}</div>}
      {loading ? (
        <p>Loading…</p>
      ) : rows.length === 0 ? (
        <p className="a-note">Nothing here yet. Use “Add new” to create the first item.</p>
      ) : (
        <ul className="a-list">
          {rows.map((r) => (
            <li key={r.id}>
              {rowThumb(r) ? <img src={rowThumb(r)} alt="" className="a-thumb" /> : <span className="a-thumb a-thumb--empty" />}
              <div className="a-list__main">
                <strong>{rowTitle(r)}</strong>
                <span>{rowMeta(r)}</span>
                <span className={`a-pill ${r.published ? 'ok' : ''}`}>{r.published ? 'Published' : 'Hidden'}</span>
              </div>
              <div className="a-actions">
                <button className="a-btn a-btn--ghost" type="button" onClick={() => togglePublished(r)}>
                  {r.published ? 'Hide' : 'Publish'}
                </button>
                <button className="a-btn a-btn--ghost" type="button" onClick={() => { setEditing({ ...r }); setMsg(''); setError('') }}>Edit</button>
                <button className="a-btn a-btn--danger" type="button" onClick={() => remove(r)}>Delete</button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
