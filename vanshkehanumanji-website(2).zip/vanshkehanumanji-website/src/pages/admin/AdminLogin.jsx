import { useState } from 'react'
import { Navigate, Link } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { isConfigured } from '../../lib/supabase'
import Logo from '../../components/Logo'

export default function AdminLogin() {
  const { session, isAdmin, loading, signIn, signOut } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  if (!isConfigured) {
    return (
      <div className="a-login">
        <div className="a-card">
          <Logo height={64} />
          <h1>Admin not connected yet</h1>
          <p>
            The database is not configured. Add <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code> (see README → Database
            configuration), then reload. There is no built-in or default password.
          </p>
          <Link to="/">← Back to website</Link>
        </div>
      </div>
    )
  }

  if (!loading && session && isAdmin) return <Navigate to="/admin" replace />

  async function submit(e) {
    e.preventDefault()
    setBusy(true)
    setError('')
    const { error: err } = await signIn(email.trim(), password)
    if (err) setError('Sign-in failed. Check your email and password.')
    setBusy(false)
  }

  return (
    <div className="a-login">
      <form className="a-card" onSubmit={submit}>
        <Logo height={64} />
        <h1>Admin sign in</h1>
        {session && !loading && !isAdmin && (
          <div className="a-error">
            This account is signed in but is not an administrator of this website.{' '}
            <button type="button" className="a-link" onClick={signOut}>Sign out</button>
          </div>
        )}
        <div className="a-field">
          <label htmlFor="em">Email</label>
          <input id="em" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div className="a-field">
          <label htmlFor="pw">Password</label>
          <input id="pw" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        {error && <div className="a-error">{error}</div>}
        <button className="a-btn" type="submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
        <p style={{ marginTop: 18 }}><Link to="/">← Back to website</Link></p>
      </form>
    </div>
  )
}
