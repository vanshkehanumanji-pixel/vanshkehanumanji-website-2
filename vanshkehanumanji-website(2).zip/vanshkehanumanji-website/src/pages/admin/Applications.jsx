import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'

const FILTERS = ['all', 'pending', 'approved', 'rejected']

function toCsv(rows) {
  const cols = ['created_at', 'status', 'full_name', 'mobile', 'whatsapp', 'city', 'state', 'age', 'instagram', 'occupation', 'reason', 'experience']
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`
  return [cols.join(','), ...rows.map((r) => cols.map((c) => esc(r[c])).join(','))].join('\n')
}

export default function Applications() {
  const [rows, setRows] = useState([])
  const [filter, setFilter] = useState('pending')
  const [open, setOpen] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    const { data, error: e } = await supabase.from('applications').select('*').order('created_at', { ascending: false })
    if (e) setError(e.message)
    else setRows(data)
    setLoading(false)
  }, [])
  useEffect(() => {
    load()
  }, [load])

  async function setStatus(id, status) {
    const { error: e } = await supabase.from('applications').update({ status }).eq('id', id)
    if (e) setError(e.message)
    else load()
  }
  async function remove(id) {
    if (!window.confirm('Delete this application permanently?')) return
    const { error: e } = await supabase.from('applications').delete().eq('id', id)
    if (e) setError(e.message)
    else load()
  }
  function exportCsv() {
    const blob = new Blob(['﻿' + toCsv(rows)], { type: 'text/csv;charset=utf-8' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `applications-${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const shown = filter === 'all' ? rows : rows.filter((r) => r.status === filter)

  return (
    <div className="a-card">
      <div className="a-head">
        <h1>Membership Applications</h1>
        <button className="a-btn a-btn--ghost" type="button" onClick={exportCsv} disabled={!rows.length}>
          Export CSV
        </button>
      </div>
      <div className="a-tabs">
        {FILTERS.map((f) => (
          <button key={f} type="button" className={filter === f ? 'on' : ''} onClick={() => setFilter(f)}>
            {f[0].toUpperCase() + f.slice(1)} ({f === 'all' ? rows.length : rows.filter((r) => r.status === f).length})
          </button>
        ))}
      </div>
      {error && <div className="a-error">{error}</div>}
      {loading ? (
        <p>Loading…</p>
      ) : !shown.length ? (
        <p className="a-note">No applications in this view.</p>
      ) : (
        <ul className="a-list">
          {shown.map((r) => (
            <li key={r.id} className="a-list--col">
              <div className="a-row">
                <div className="a-list__main">
                  <strong>{r.full_name}</strong>
                  <span>{r.city}, {r.state} · {r.mobile} · {new Date(r.created_at).toLocaleDateString('en-IN')}</span>
                  <span className={`a-pill ${r.status === 'approved' ? 'ok' : r.status === 'rejected' ? 'bad' : ''}`}>{r.status}</span>
                </div>
                <div className="a-actions">
                  <button className="a-btn a-btn--ghost" type="button" onClick={() => setOpen(open === r.id ? null : r.id)}>
                    {open === r.id ? 'Hide' : 'View'}
                  </button>
                  <button className="a-btn" type="button" onClick={() => setStatus(r.id, 'approved')} disabled={r.status === 'approved'}>Approve</button>
                  <button className="a-btn a-btn--danger" type="button" onClick={() => setStatus(r.id, 'rejected')} disabled={r.status === 'rejected'}>Reject</button>
                </div>
              </div>
              {open === r.id && (
                <dl className="a-detail">
                  <dt>WhatsApp</dt><dd>{r.whatsapp}</dd>
                  <dt>Age</dt><dd>{r.age}</dd>
                  <dt>Instagram</dt><dd>{r.instagram ? `@${r.instagram}` : '—'}</dd>
                  <dt>Occupation</dt><dd>{r.occupation}</dd>
                  <dt>Why join</dt><dd style={{ whiteSpace: 'pre-line' }}>{r.reason}</dd>
                  <dt>Volunteer experience</dt><dd style={{ whiteSpace: 'pre-line' }}>{r.experience || '—'}</dd>
                  <dd className="a-actions">
                    <button className="a-btn a-btn--ghost" type="button" onClick={() => setStatus(r.id, 'pending')} disabled={r.status === 'pending'}>Mark pending</button>
                    <button className="a-btn a-btn--danger" type="button" onClick={() => remove(r.id)}>Delete</button>
                  </dd>
                </dl>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
