import { TEAM_CATEGORIES, SEVA_CATEGORIES, GALLERY_SECTIONS, ANNOUNCEMENT_KINDS } from '../../lib/defaults'

const opts = (list) => list.map((c) => ({ value: c.id, label: c.en }))

// ---- Site content editors: stored in `site_content` (one row per key) ----
// types: text | textarea (plain string)   bitext | bitextarea ({en, hi})   image (url)
export const contentSchemas = {
  site: {
    title: 'Logo',
    fields: [{ path: 'logo', label: 'Official logo (upload your original logo file)', type: 'image', folder: 'site' }],
  },
  home: {
    title: 'Homepage',
    fields: [
      { path: 'heroImage', label: 'Hero photograph', type: 'image', folder: 'site' },
      { path: 'heroText', label: 'Hero supporting text', type: 'bitextarea' },
      { path: 'who', label: 'Who We Are', type: 'bitextarea' },
      { path: 'stand', label: 'What We Stand For', type: 'bitextarea' },
      { path: 'purpose', label: 'Our Purpose', type: 'bitextarea' },
      { path: 'ctaTitle', label: 'Join CTA heading', type: 'bitext' },
      { path: 'ctaText', label: 'Join CTA text', type: 'bitextarea' },
    ],
  },
  about: {
    title: 'About Us',
    fields: [
      { path: 'story', label: 'Our Story', type: 'bitextarea' },
      { path: 'purpose', label: 'Our Purpose', type: 'bitextarea' },
      { path: 'mission', label: 'Our Mission', type: 'bitextarea' },
      { path: 'vision', label: 'Our Vision', type: 'bitextarea' },
      { path: 'commitment', label: 'Our Commitment', type: 'bitextarea' },
      ...[0, 1, 2, 3, 4, 5].map((i) => ({ path: `values.${i}`, label: `Value ${i + 1}`, type: 'bitext' })),
    ],
  },
  founder: {
    title: 'Founder',
    fields: [
      { path: 'photo', label: 'Founder photograph (use your original photo)', type: 'image', folder: 'site' },
      { path: 'name', label: 'Name', type: 'bitext' },
      { path: 'designation', label: 'Designation', type: 'bitext' },
      { path: 'location', label: 'Location', type: 'bitext' },
      { path: 'intro', label: 'Founder introduction', type: 'bitextarea' },
      { path: 'message', label: 'Leadership message', type: 'bitextarea' },
    ],
  },
  contact: {
    title: 'Contact & Social Links',
    fields: [
      { path: 'instagram', label: 'Instagram handle (display)', type: 'text' },
      { path: 'instagramUrl', label: 'Instagram URL', type: 'text' },
      { path: 'whatsapp', label: 'WhatsApp number (display)', type: 'text' },
      { path: 'whatsappUrl', label: 'WhatsApp URL (https://wa.me/91XXXXXXXXXX)', type: 'text' },
      { path: 'email', label: 'Official email', type: 'text' },
      { path: 'facebookUrl', label: 'Facebook URL (leave empty to hide)', type: 'text' },
      { path: 'youtubeUrl', label: 'YouTube URL (leave empty to hide)', type: 'text' },
      { path: 'location', label: 'Location', type: 'bitext' },
    ],
  },
}

// ---- Collection managers ----
export const collections = {
  team: {
    table: 'team_members',
    title: 'Team Members',
    orderBy: 'sort_order',
    asc: true,
    blank: { category: 'member', name: '', designation: '', city: '', description: '', photo_url: '', sort_order: 0, published: true },
    rowTitle: (r) => r.name,
    rowMeta: (r) => [TEAM_CATEGORIES.find((c) => c.id === r.category)?.en, r.designation, r.city].filter(Boolean).join(' · '),
    rowThumb: (r) => r.photo_url,
    fields: [
      { name: 'category', label: 'Category', type: 'select', options: opts(TEAM_CATEGORIES), required: true },
      { name: 'name', label: 'Name', type: 'text', required: true },
      { name: 'designation', label: 'Designation', type: 'text' },
      { name: 'city', label: 'City', type: 'text' },
      { name: 'description', label: 'Description', type: 'textarea' },
      { name: 'photo_url', label: 'Photograph (member\'s real photo only)', type: 'image', folder: 'team' },
      { name: 'sort_order', label: 'Display order (lower = first)', type: 'number' },
      { name: 'published', label: 'Visible on website', type: 'checkbox' },
    ],
  },
  seva: {
    table: 'seva_activities',
    title: 'Seva Activities',
    orderBy: 'created_at',
    asc: false,
    blank: { category: 'social', title: '', title_hi: '', description: '', description_hi: '', photo_url: '', activity_date: '', location: '', sort_order: 0, published: true },
    rowTitle: (r) => r.title,
    rowMeta: (r) => [SEVA_CATEGORIES.find((c) => c.id === r.category)?.en, r.activity_date, r.location].filter(Boolean).join(' · '),
    rowThumb: (r) => r.photo_url,
    fields: [
      { name: 'category', label: 'Category', type: 'select', options: opts(SEVA_CATEGORIES), required: true },
      { name: 'title', label: 'Title (English)', type: 'text', required: true },
      { name: 'title_hi', label: 'Title (Hindi)', type: 'text' },
      { name: 'description', label: 'Description (English)', type: 'textarea' },
      { name: 'description_hi', label: 'Description (Hindi)', type: 'textarea' },
      { name: 'photo_url', label: 'Original photograph', type: 'image', folder: 'seva' },
      { name: 'activity_date', label: 'Date', type: 'date' },
      { name: 'location', label: 'Location', type: 'text' },
      { name: 'published', label: 'Visible on website', type: 'checkbox' },
    ],
  },
  gallery: {
    table: 'gallery_items',
    title: 'Gallery',
    orderBy: 'created_at',
    asc: false,
    blank: { section: 'team', media_type: 'image', url: '', caption: '', caption_hi: '', sort_order: 0, published: true },
    rowTitle: (r) => r.caption || (r.media_type === 'video' ? 'Video' : 'Photo'),
    rowMeta: (r) => [GALLERY_SECTIONS.find((c) => c.id === r.section)?.en, r.media_type].filter(Boolean).join(' · '),
    rowThumb: (r) => (r.media_type === 'image' ? r.url : null),
    fields: [
      { name: 'section', label: 'Section', type: 'select', options: opts(GALLERY_SECTIONS), required: true },
      { name: 'media_type', label: 'Type', type: 'select', options: [{ value: 'image', label: 'Photo' }, { value: 'video', label: 'Video' }], required: true },
      { name: 'url', label: 'Photo / video (upload, or paste a YouTube link for videos)', type: 'media', folder: 'gallery', required: true },
      { name: 'caption', label: 'Caption (English)', type: 'text' },
      { name: 'caption_hi', label: 'Caption (Hindi)', type: 'text' },
      { name: 'sort_order', label: 'Display order (lower = first)', type: 'number' },
      { name: 'published', label: 'Visible on website', type: 'checkbox' },
    ],
  },
  announcements: {
    table: 'announcements',
    title: 'Announcements',
    orderBy: 'published_at',
    asc: false,
    blank: { kind: 'announcement', title: '', title_hi: '', body: '', body_hi: '', event_date: '', published: true },
    rowTitle: (r) => r.title,
    rowMeta: (r) => [ANNOUNCEMENT_KINDS.find((c) => c.id === r.kind)?.en, r.published_at?.slice(0, 10)].filter(Boolean).join(' · '),
    rowThumb: () => null,
    fields: [
      { name: 'kind', label: 'Type', type: 'select', options: opts(ANNOUNCEMENT_KINDS), required: true },
      { name: 'title', label: 'Title (English)', type: 'text', required: true },
      { name: 'title_hi', label: 'Title (Hindi)', type: 'text' },
      { name: 'body', label: 'Details (English)', type: 'textarea' },
      { name: 'body_hi', label: 'Details (Hindi)', type: 'textarea' },
      { name: 'event_date', label: 'Event date (for upcoming events)', type: 'date' },
      { name: 'published', label: 'Visible on website', type: 'checkbox' },
    ],
  },
}
