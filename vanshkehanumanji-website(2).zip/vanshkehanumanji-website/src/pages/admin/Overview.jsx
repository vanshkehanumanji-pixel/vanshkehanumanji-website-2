import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabase'

const TABLES = ['site_content', 'team_members', 'seva_activities', 'gallery_items', 'announcements', 'applications', 'contact_messages']

async function count(table, filter) {
  let q = supabase.from(table).select('*', { count: 'exact', head: true })
  if (filter) q = q.eq(filter[0], filter[1])
  const { count: c } = await q
  return c ?? 0
}

export default function Overview() {
  const [stats, setStats] = useState(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    let off = false
    Promise.all([
      count('applications', ['status', 'pending']),
      count('contact_messages', ['is_read', false]),
      count('team_members'),
      count('seva_activities'),
      count('gallery_items'),
      count('announcements'),
    ]).then(([pending, unread, team, seva, gallery, ann]) => {
      if (!off) setStats({ pending, unread, team, seva, gallery, ann })
    })
    return () => {
      off = true
    }
  }, [])

  // One-click backup of all database content as a JSON file (files in storage are
  // backed up separately — see README "Backups").
  async function backup() {
    setBusy(true)
    const out = { exported_at: new Date().toISOString() }
    for (const t of TABLES) {
      const { data } = await supabase.from(t).select('*')
      out[t] = data || []
    }
    const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `vanshkehanumanji-backup-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(a.href)
    setBusy(false)
  }

  const cards = stats && [
    ['Pending applications', stats.pending, '/admin/applications'],
    ['Unread messages', stats.unread, '/admin/messages'],
    ['Team members', stats.team, '/admin/team'],
    ['Seva activities', stats.seva, '/admin/seva'],
    ['Gallery items', stats.gallery, '/admin/gallery'],
    ['Announcements', stats.ann, '/admin/announcements'],
  ]

  return (
    <div>
      <div className="a-card">
        <h1>Dashboard</h1>
        <p className="a-note">Welcome. Use the menu to edit pages and publish content. Changes go live immediately.</p>
        <div className="a-stats">
          {!cards && <p>Loading…</p>}
          {cards?.map(([label, n, to]) => (
            <Link key={label} to={to} className="a-stat">
              <b>{n}</b>
              <span>{label}</span>
            </Link>
          ))}
        </div>
      </div>
      <div className="a-card">
        <h2>Backup</h2>
        <p className="a-note">Download all website data (content, team, applications, messages) as one JSON file. Do this regularly and keep it somewhere safe.</p>
        <button className="a-btn" type="button" onClick={backup} disabled={busy}>
          {busy ? 'Preparing…' : 'Download data backup'}
        </button>
      </div>
    </div>
  )
}
