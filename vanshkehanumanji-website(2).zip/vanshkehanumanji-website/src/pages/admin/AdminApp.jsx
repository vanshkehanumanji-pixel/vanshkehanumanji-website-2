import { useEffect, useState } from 'react'
import { Navigate, NavLink, Outlet, Route, Routes, useLocation } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import Logo from '../../components/Logo'
import AdminLogin from './AdminLogin'
import Overview from './Overview'
import ContentEditor from './ContentEditor'
import CollectionManager from './CollectionManager'
import Applications from './Applications'
import Messages from './Messages'
import { contentSchemas, collections } from './schemas'
import './admin.css'

const MENU = [
  ['/admin', 'Overview', true],
  ['/admin/site', 'Logo'],
  ['/admin/home', 'Homepage'],
  ['/admin/about', 'About Us'],
  ['/admin/founder', 'Founder'],
  ['/admin/contact', 'Contact & Social'],
  ['/admin/team', 'Team Members'],
  ['/admin/seva', 'Seva Activities'],
  ['/admin/gallery', 'Gallery'],
  ['/admin/announcements', 'Announcements'],
  ['/admin/applications', 'Applications'],
  ['/admin/messages', 'Messages'],
]

// Every route below this guard requires a signed-in user who is in `admins`.
// (The database enforces the same rule with Row Level Security.)
function RequireAdmin() {
  const { session, isAdmin, loading, signOut } = useAuth()
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()
  useEffect(() => setOpen(false), [pathname])

  if (loading) return <div className="a-login"><p>Checking access…</p></div>
  if (!session || !isAdmin) return <Navigate to="/admin/login" replace />

  return (
    <div className="a-shell">
      <header className="a-top">
        <Logo height={36} />
        <strong>Admin</strong>
        <button type="button" className="a-btn a-btn--ghost a-menu-btn" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
          Menu
        </button>
      </header>
      <aside className={`a-side ${open ? 'open' : ''}`}>
        <nav aria-label="Admin">
          {MENU.map(([to, label, end]) => (
            <NavLink key={to} to={to} end={end}>{label}</NavLink>
          ))}
          <a href="/" target="_blank" rel="noopener noreferrer">View website ↗</a>
          <button type="button" onClick={signOut}>Sign out</button>
        </nav>
      </aside>
      <main className="a-main">
        <Outlet />
      </main>
    </div>
  )
}

export default function AdminApp() {
  useEffect(() => {
    document.title = 'Admin | VanshkeHanumanji Team'
    const meta = document.createElement('meta')
    meta.name = 'robots'
    meta.content = 'noindex,nofollow'
    document.head.appendChild(meta)
    return () => meta.remove()
  }, [])

  return (
    <Routes>
      <Route path="login" element={<AdminLogin />} />
      <Route element={<RequireAdmin />}>
        <Route index element={<Overview />} />
        {Object.entries(contentSchemas).map(([key, s]) => (
          <Route key={key} path={key} element={<ContentEditor key={key} contentKey={key} title={s.title} fields={s.fields} />} />
        ))}
        {Object.entries(collections).map(([key, cfg]) => (
          <Route key={key} path={key} element={<CollectionManager key={key} config={cfg} />} />
        ))}
        <Route path="applications" element={<Applications />} />
        <Route path="messages" element={<Messages />} />
        <Route path="*" element={<Navigate to="/admin" replace />} />
      </Route>
    </Routes>
  )
}
