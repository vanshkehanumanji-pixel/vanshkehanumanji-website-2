import { useState } from 'react'
import { uploadFile } from '../../lib/upload'

function FileInput({ value, onChange, folder, accept, allowUrl }) {
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const isVideo = /\.(mp4|webm|mov)(\?|$)/i.test(value || '')
  const isImage = value && !isVideo && !/youtu/.test(value)

  async function pick(e) {
    const file = e.target.files?.[0]
    if (!file) return
    setBusy(true)
    setErr('')
    try {
      onChange(await uploadFile(file, folder))
    } catch (ex) {
      setErr(ex.message || 'Upload failed.')
    } finally {
      setBusy(false)
      e.target.value = ''
    }
  }

  return (
    <div className="file-input">
      {isImage && <img className="file-input__preview" src={value} alt="" />}
      {value && !isImage && <div className="file-input__url">{value}</div>}
      <div className="file-input__row">
        <input type="file" accept={accept} onChange={pick} disabled={busy} />
        {value && (
          <button type="button" className="a-btn a-btn--ghost" onClick={() => onChange('')}>
            Remove
          </button>
        )}
      </div>
      {allowUrl && (
        <input
          type="url"
          placeholder="…or paste a link (e.g. YouTube)"
          value={value && !value.includes('/storage/v1/object/') ? value : ''}
          onChange={(e) => onChange(e.target.value)}
        />
      )}
      {busy && <div className="a-note">Uploading…</div>}
      {err && <div className="a-error">{err}</div>}
    </div>
  )
}

// Renders one editable form control. `field.type` decides which.
export default function FieldInput({ field, value, onChange }) {
  const id = `f-${field.name || field.path}`
  const v = value ?? ''
  switch (field.type) {
    case 'textarea':
      return <textarea id={id} rows={4} value={v} required={field.required} onChange={(e) => onChange(e.target.value)} />
    case 'select':
      return (
        <select id={id} value={v} required={field.required} onChange={(e) => onChange(e.target.value)}>
          {field.options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      )
    case 'date':
      return <input id={id} type="date" value={v} required={field.required} onChange={(e) => onChange(e.target.value)} />
    case 'number':
      return <input id={id} type="number" value={v} onChange={(e) => onChange(e.target.value)} />
    case 'checkbox':
      return (
        <label className="a-check">
          <input id={id} type="checkbox" checked={Boolean(value)} onChange={(e) => onChange(e.target.checked)} /> Yes
        </label>
      )
    case 'image':
      return <FileInput value={v} onChange={onChange} folder={field.folder || 'misc'} accept="image/*" />
    case 'media':
      return <FileInput value={v} onChange={onChange} folder={field.folder || 'misc'} accept="image/*,video/*" allowUrl />
    default:
      return <input id={id} type="text" value={v} required={field.required} onChange={(e) => onChange(e.target.value)} />
  }
}
