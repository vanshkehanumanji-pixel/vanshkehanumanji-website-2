import { useState } from 'react'
import { useLang } from '../context/LangContext'
import { useCollection } from '../lib/useCollection'
import { useMeta } from '../lib/useMeta'
import { ANNOUNCEMENT_KINDS } from '../lib/defaults'
import { PageBanner, EmptyState } from '../components/ui'
import { AnnouncementItem } from '../components/cards'

export default function Announcements() {
  const { t, lang } = useLang()
  useMeta(t('nav.announcements'), t('ann.metaDesc'))
  const { rows, loading } = useCollection('announcements', { order: 'published_at', asc: false })
  const [kind, setKind] = useState('all')
  const shown = kind === 'all' ? rows : rows.filter((r) => r.kind === kind)

  return (
    <>
      <PageBanner eyebrow={t('ann.eyebrow')} title={t('ann.title')} />
      <section className="section section--ivory">
        <div className="container">
          <div className="chips" role="group" aria-label="Types">
            <button type="button" className="chip" aria-pressed={kind === 'all'} onClick={() => setKind('all')}>
              {t('seva.all')}
            </button>
            {ANNOUNCEMENT_KINDS.map((k) => (
              <button key={k.id} type="button" className="chip" aria-pressed={kind === k.id} onClick={() => setKind(k.id)}>
                {k[lang]}
              </button>
            ))}
          </div>
          {loading ? (
            <p className="muted">{t('common.loading')}</p>
          ) : shown.length ? (
            shown.map((r) => <AnnouncementItem key={r.id} item={r} />)
          ) : (
            <EmptyState title={t('ann.soon')} text={t('ann.soonText')} />
          )}
        </div>
      </section>
    </>
  )
}
