import { useState } from 'react'
import { useLang } from '../context/LangContext'
import { useContent } from '../context/ContentContext'
import { useMeta } from '../lib/useMeta'
import { supabase, isConfigured } from '../lib/supabase'
import { PageBanner, Field, SectionHeading } from '../components/ui'
import Icon from '../components/Icon'

const empty = { name: '', email: '', phone: '', message: '', website: '' }

export default function Contact() {
  const { t, tx } = useLang()
  const { content } = useContent()
  const c = content.contact
  useMeta(t('nav.contact'), t('contact.metaDesc'))

  const [form, setForm] = useState(empty)
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState('idle')
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))

  async function onSubmit(ev) {
    ev.preventDefault()
    if (form.website) return
    const e = {}
    if (form.name.trim().length < 2) e.name = t('err.required')
    if (!/^\S+@\S+\.\S+$/.test(form.email.trim())) e.email = t('err.email')
    if (form.message.trim().length < 5) e.message = t('err.required')
    setErrors(e)
    if (Object.keys(e).length) return
    if (!isConfigured) {
      setStatus('error')
      return
    }
    setStatus('sending')
    const { error } = await supabase.from('contact_messages').insert({
      name: form.name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim() || null,
      message: form.message.trim(),
    })
    if (error) setStatus('error')
    else {
      setStatus('ok')
      setForm(empty)
    }
  }

  return (
    <>
      <PageBanner eyebrow={t('contact.eyebrow')} title={t('contact.title')} />
      <section className="section section--sand">
        <div className="container split">
          <div>
            <SectionHeading eyebrow={t('contact.eyebrow')} title={t('contact.title')} />
            <div className="contact-list">
              {c.instagramUrl && (
                <a className="contact-item" href={c.instagramUrl} target="_blank" rel="noopener noreferrer">
                  <Icon name="instagram" size={24} />
                  <div><strong>{t('contact.instagram')}</strong><span>{c.instagram}</span></div>
                </a>
              )}
              {c.whatsappUrl && (
                <a className="contact-item" href={c.whatsappUrl} target="_blank" rel="noopener noreferrer">
                  <Icon name="whatsapp" size={24} />
                  <div><strong>{t('contact.whatsapp')}</strong><span>{c.whatsapp}</span></div>
                </a>
              )}
              {c.email && (
                <a className="contact-item" href={`mailto:${c.email}`}>
                  <Icon name="mail" size={24} />
                  <div><strong>{t('contact.email')}</strong><span>{c.email}</span></div>
                </a>
              )}
              {c.facebookUrl && (
                <a className="contact-item" href={c.facebookUrl} target="_blank" rel="noopener noreferrer">
                  <Icon name="link" size={24} />
                  <div><strong>Facebook</strong><span>{c.facebookUrl}</span></div>
                </a>
              )}
              {c.youtubeUrl && (
                <a className="contact-item" href={c.youtubeUrl} target="_blank" rel="noopener noreferrer">
                  <Icon name="link" size={24} />
                  <div><strong>YouTube</strong><span>{c.youtubeUrl}</span></div>
                </a>
              )}
              <div className="contact-item">
                <Icon name="pin" size={24} />
                <div><strong>{t('contact.location')}</strong><span>{tx(c.location)}</span></div>
              </div>
            </div>
          </div>

          <div>
            <h2 style={{ fontSize: '1.9rem' }}>{t('contact.formTitle')}</h2>
            {!isConfigured && <div className="alert alert--info" role="status" style={{ marginBottom: 18 }}>{t('contact.notConnected')}</div>}
            {status === 'ok' ? (
              <div className="alert alert--ok" role="status">{t('contact.success')}</div>
            ) : (
              <form className="form form-card" onSubmit={onSubmit} noValidate>
                <div className="hp" aria-hidden="true">
                  <label>Website <input tabIndex={-1} autoComplete="off" value={form.website} onChange={set('website')} /></label>
                </div>
                <Field id="c_name" label={`${t('contact.name')} *`} error={errors.name}>
                  <input id="c_name" type="text" autoComplete="name" maxLength={100} value={form.name} onChange={set('name')} />
                </Field>
                <div className="form__row">
                  <Field id="c_email" label={`${t('contact.emailField')} *`} error={errors.email}>
                    <input id="c_email" type="email" autoComplete="email" maxLength={150} value={form.email} onChange={set('email')} />
                  </Field>
                  <Field id="c_phone" label={t('contact.phone')}>
                    <input id="c_phone" type="tel" autoComplete="tel" maxLength={20} value={form.phone} onChange={set('phone')} />
                  </Field>
                </div>
                <Field id="c_message" label={`${t('contact.message')} *`} error={errors.message}>
                  <textarea id="c_message" maxLength={3000} value={form.message} onChange={set('message')} />
                </Field>
                {status === 'error' && <div className="alert alert--err" role="alert">{isConfigured ? t('contact.error') : t('contact.notConnected')}</div>}
                <button className="btn btn--saffron" type="submit" disabled={status === 'sending'}>
                  {status === 'sending' ? t('join.sending') : t('contact.send')}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </>
  )
}
