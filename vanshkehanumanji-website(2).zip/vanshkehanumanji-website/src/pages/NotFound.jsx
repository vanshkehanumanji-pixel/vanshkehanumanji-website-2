import { Link } from 'react-router-dom'
import { useLang } from '../context/LangContext'
import { useMeta } from '../lib/useMeta'

export default function NotFound() {
  const { t } = useLang()
  useMeta(t('nf.title'), t('nf.text'))
  return (
    <section className="notfound">
      <div>
        <div className="big">404</div>
        <h1 style={{ fontSize: '2rem' }}>{t('nf.title')}</h1>
        <p style={{ color: 'rgba(255,248,235,.75)' }}>{t('nf.text')}</p>
        <Link className="btn btn--saffron" to="/">{t('nf.home')}</Link>
      </div>
    </section>
  )
}
