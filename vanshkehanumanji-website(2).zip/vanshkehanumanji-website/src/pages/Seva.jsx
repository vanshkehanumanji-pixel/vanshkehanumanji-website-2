import { useState } from 'react'
import { useLang } from '../context/LangContext'
import { useCollection } from '../lib/useCollection'
import { useMeta } from '../lib/useMeta'
import { SEVA_CATEGORIES } from '../lib/defaults'
import { PageBanner, EmptyState } from '../components/ui'
import { SevaCard } from '../components/cards'

export default function Seva() {
  const { t, lang } = useLang()
  useMeta(t('nav.seva'), t('seva.metaDesc'))
  const { rows, loading } = useCollection('seva_activities', { order: 'activity_date', asc: false })
  const [cat, setCat] = useState('all')
  const shown = cat === 'all' ? rows : rows.filter((r) => r.category === cat)

  return (
    <>
      <PageBanner eyebrow={t('seva.eyebrow')} title={t('seva.title')} />
      <section className="section section--ivory">
        <div className="container">
          <div className="chips" role="group" aria-label="Categories">
            <button type="button" className="chip" aria-pressed={cat === 'all'} onClick={() => setCat('all')}>
              {t('seva.all')}
            </button>
            {SEVA_CATEGORIES.map((c) => (
              <button key={c.id} type="button" className="chip" aria-pressed={cat === c.id} onClick={() => setCat(c.id)}>
                {c[lang]}
              </button>
            ))}
          </div>

          {loading ? (
            <p className="muted">{t('common.loading')}</p>
          ) : shown.length ? (
            <div className="grid grid--3">
              {shown.map((r) => (
                <SevaCard key={r.id} item={r} />
              ))}
            </div>
          ) : (
            <EmptyState title={t('seva.soon')} text={t('seva.soonText')} />
          )}
        </div>
      </section>
    </>
  )
}
