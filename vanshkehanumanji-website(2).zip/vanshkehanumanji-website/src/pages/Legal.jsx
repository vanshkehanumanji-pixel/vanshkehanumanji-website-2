import { useLang } from '../context/LangContext'
import { useContent } from '../context/ContentContext'
import { useMeta } from '../lib/useMeta'
import { PageBanner } from '../components/ui'

// NOTE FOR OWNER: these are plain-language starter texts that describe how this
// website actually works. Please have them reviewed by a qualified legal adviser
// before relying on them.

export function Privacy() {
  const { lang, t } = useLang()
  const { content } = useContent()
  const email = content.contact.email
  useMeta(t('footer.privacy'), 'Privacy Policy of VanshkeHanumanji Team website.')
  const hi = lang === 'hi'

  return (
    <>
      <PageBanner eyebrow="Legal" title={t('footer.privacy')} />
      <section className="section section--ivory">
        <div className="container prose">
          <p className="muted">{hi ? 'अंतिम अपडेट: 22 नवंबर 2026' : 'Last updated: 22 November 2026'}</p>
          {hi ? (
            <>
              <h2>हम कौन सी जानकारी लेते हैं</h2>
              <p>जब आप सदस्यता आवेदन या संपर्क फ़ॉर्म भरते हैं, तब आपके द्वारा दी गई जानकारी (जैसे नाम, मोबाइल/WhatsApp नंबर, शहर, राज्य, आयु, Instagram यूज़रनेम, व्यवसाय, आवेदन का कारण, अनुभव, ईमेल और संदेश) हम एकत्र करते हैं।</p>
              <h2>जानकारी का उपयोग</h2>
              <p>यह जानकारी केवल आपके आवेदन की समीक्षा करने, आपके संदेश का उत्तर देने और टीम से संपर्क बनाने के लिए उपयोग की जाती है। आपकी जानकारी बेची नहीं जाती।</p>
              <h2>जानकारी कहाँ सुरक्षित रहती है</h2>
              <p>जानकारी एक सुरक्षित डेटाबेस (Supabase) में रखी जाती है, जिसे केवल अधिकृत एडमिन देख सकते हैं।</p>
              <h2>आपके अधिकार</h2>
              <p>अपनी जानकारी देखने, सुधारने या हटवाने के लिए आप हमसे {email || 'आधिकारिक संपर्क माध्यम'} पर संपर्क कर सकते हैं।</p>
              <h2>बाहरी लिंक</h2>
              <p>वेबसाइट पर Instagram और WhatsApp जैसे बाहरी लिंक हो सकते हैं। उनकी अपनी गोपनीयता नीतियाँ लागू होती हैं।</p>
            </>
          ) : (
            <>
              <h2>What we collect</h2>
              <p>When you submit the membership application or the contact form, we collect the details you enter: name, mobile / WhatsApp number, city, state, age, Instagram username, occupation, your reason for joining, volunteer experience, email and message.</p>
              <h2>How we use it</h2>
              <p>This information is used only to review your application, reply to your message and stay in touch with you about the team. Your information is not sold.</p>
              <h2>Where it is stored</h2>
              <p>Submissions are stored in a secure database (Supabase) that only authorised administrators of this website can read.</p>
              <h2>Your rights</h2>
              <p>To see, correct or delete your information, contact us at {email || 'our official contact channels'}.</p>
              <h2>External links</h2>
              <p>This website links to external services such as Instagram and WhatsApp. Their own privacy policies apply once you leave this site.</p>
            </>
          )}
        </div>
      </section>
    </>
  )
}

export function Terms() {
  const { lang, t } = useLang()
  useMeta(t('footer.terms'), 'Terms and Conditions of the VanshkeHanumanji Team website.')
  const hi = lang === 'hi'

  return (
    <>
      <PageBanner eyebrow="Legal" title={t('footer.terms')} />
      <section className="section section--ivory">
        <div className="container prose">
          <p className="muted">{hi ? 'अंतिम अपडेट: 22 नवंबर 2026' : 'Last updated: 22 November 2026'}</p>
          {hi ? (
            <>
              <h2>वेबसाइट का उपयोग</h2>
              <p>इस वेबसाइट का उपयोग करके आप इन शर्तों से सहमत होते हैं। कृपया वेबसाइट का उपयोग केवल वैध और सम्मानजनक उद्देश्यों के लिए करें।</p>
              <h2>सही जानकारी</h2>
              <p>आवेदन या संपर्क फ़ॉर्म में आप जो जानकारी देते हैं वह सही होनी चाहिए। आवेदन जमा करना सदस्यता की गारंटी नहीं है; टीम अपने विवेक से निर्णय लेती है।</p>
              <h2>सामग्री</h2>
              <p>वेबसाइट की सामग्री, लोगो और तस्वीरें VanshkeHanumanji Team की हैं। अनुमति के बिना उनकी नकल या पुनः प्रकाशन न करें।</p>
              <h2>दायित्व की सीमा</h2>
              <p>हम वेबसाइट की जानकारी को सही रखने का प्रयास करते हैं, परंतु इसकी निरंतर उपलब्धता या पूर्ण त्रुटिहीनता की गारंटी नहीं देते।</p>
              <h2>परिवर्तन</h2>
              <p>ये शर्तें समय-समय पर बदली जा सकती हैं। बदलाव इसी पृष्ठ पर प्रकाशित होंगे।</p>
            </>
          ) : (
            <>
              <h2>Use of this website</h2>
              <p>By using this website you agree to these terms. Please use it only for lawful and respectful purposes.</p>
              <h2>Accurate information</h2>
              <p>Information you submit through forms must be accurate. Submitting an application does not guarantee membership; the team decides at its discretion.</p>
              <h2>Content</h2>
              <p>The website content, logo and photographs belong to VanshkeHanumanji Team. Please do not copy or republish them without permission.</p>
              <h2>Limitation of liability</h2>
              <p>We try to keep the information accurate but do not guarantee uninterrupted availability or that the site is free of errors.</p>
              <h2>Changes</h2>
              <p>These terms may be updated from time to time. Changes will be published on this page.</p>
            </>
          )}
        </div>
      </section>
    </>
  )
}
