import { Link } from 'react-router-dom'
import { useLang } from '../context/LangContext'
import { useContent } from '../context/ContentContext'
import { useCollection } from '../lib/useCollection'
import { useMeta } from '../lib/useMeta'
import { SectionHeading, FramedPhoto, EmptyState } from '../components/ui'
import { SevaCard, AnnouncementItem, GalleryTile } from '../components/cards'
import Lightbox from '../components/Lightbox'
import Icon from '../components/Icon'
import { useState } from 'react'

export default function Home() {
  const { t, tx, lang } = useLang()
  const { content } = useContent()
  const { site, home, about, founder } = content
  useMeta('', tx(home.heroText))

  const seva = useCollection('seva_activities', { order: 'created_at', asc: false, limit: 3 })
  const gallery = useCollection('gallery_items', { order: 'sort_order', asc: true, limit: 6, filter: { media_type: 'image' } })
  const ann = useCollection('announcements', { order: 'published_at', asc: false, limit: 3 })
  const [lb, setLb] = useState(null)

  return (
    <>
      {/* HERO */}
      <section className="hero">
        <div className="container hero__grid">
          <div className="reveal">
            <span className="eyebrow" style={{ color: 'var(--gold)' }}>{tx(content.contact.location)}</span>
            <h1 className="hero__brand">{site.name}</h1>
            <p className="hero__headline">{site.tagline.hi}</p>
            {lang === 'en' && <p className="hero__translation">{site.tagline.en}</p>}
            <p className="hero__sub">{tx(home.heroText)}</p>
            <div className="btn-row">
              <Link className="btn btn--saffron" to="/about">
                {t('hero.explore')} <Icon name="arrow" size={18} />
              </Link>
              <Link className="btn btn--outline" to="/join">
                {t('hero.join')}
              </Link>
            </div>
          </div>
          <div className="hero__visual reveal" style={{ animationDelay: '0.15s' }}>
            <FramedPhoto src={home.heroImage} alt={`${tx(founder.name)} — ${site.name}`} fallback="logo" />
          </div>
        </div>
      </section>

      {/* INTRODUCTION */}
      <section className="section section--ivory">
        <div className="container">
          <SectionHeading eyebrow={t('home.introEyebrow')} title={t('home.introTitle')} center />
          <div className="grid grid--3">
            {[
              ['01', 'home.who', home.who],
              ['02', 'home.stand', home.stand],
              ['03', 'home.purpose', home.purpose],
            ].map(([n, key, body]) => (
              <article className="card" key={key}>
                <span className="card__num">{n}</span>
                <h3>{t(key)}</h3>
                <p style={{ marginBottom: 0 }}>{tx(body)}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* MISSION & VISION */}
      <section className="section section--maroon">
        <div className="container split">
          <div>
            <span className="eyebrow">{t('about.mission')}</span>
            <h2>{t('about.mission')}</h2>
            <div className="quote-panel"><p>{tx(about.mission)}</p></div>
          </div>
          <div>
            <span className="eyebrow">{t('about.vision')}</span>
            <h2>{t('about.vision')}</h2>
            <div className="quote-panel"><p>{tx(about.vision)}</p></div>
          </div>
        </div>
      </section>

      {/* FOUNDER PREVIEW */}
      <section className="section section--sand">
        <div className="container founder-hero">
          <div style={{ maxWidth: 380 }}>
            <FramedPhoto src={founder.photo} alt={tx(founder.name)} />
          </div>
          <div>
            <span className="eyebrow">{t('founder.preview')}</span>
            <h2>{tx(founder.name)}</h2>
            <p className="muted" style={{ fontWeight: 600 }}>{tx(founder.designation)} · {tx(founder.location)}</p>
            <div className="quote-panel" style={{ margin: '22px 0' }}>
              <p>“{tx(founder.message)}”</p>
            </div>
            <Link className="link-arrow" to="/founder">
              {t('founder.read')} <Icon name="arrow" size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* SEVA PREVIEW */}
      <section className="section section--ivory">
        <div className="container">
          <SectionHeading eyebrow={t('seva.eyebrow')} title={t('seva.preview')} center />
          {seva.rows.length ? (
            <div className="grid grid--3">
              {seva.rows.map((r) => (
                <SevaCard key={r.id} item={r} />
              ))}
            </div>
          ) : (
            <EmptyState title={t('seva.soon')} text={t('seva.soonText')} />
          )}
          <p style={{ textAlign: 'center', marginTop: 32 }}>
            <Link className="link-arrow" to="/seva">
              {t('seva.viewAll')} <Icon name="arrow" size={18} />
            </Link>
          </p>
        </div>
      </section>

      {/* GALLERY PREVIEW */}
      <section className="section section--black">
        <div className="container">
          <SectionHeading eyebrow={t('gallery.eyebrow')} title={t('gallery.title')} center />
          {gallery.rows.length ? (
            <div className="gallery-grid">
              {gallery.rows.map((r, i) => (
                <GalleryTile key={r.id} item={r} onOpen={() => setLb(i)} />
              ))}
            </div>
          ) : (
            <EmptyState title={t('gallery.soon')} text={t('gallery.soonText')} />
          )}
          <p style={{ textAlign: 'center', marginTop: 32 }}>
            <Link className="link-arrow" to="/gallery">
              {t('gallery.viewAll')} <Icon name="arrow" size={18} />
            </Link>
          </p>
        </div>
        {lb !== null && <Lightbox items={gallery.rows} index={lb} onChange={setLb} onClose={() => setLb(null)} />}
      </section>

      {/* ANNOUNCEMENTS */}
      <section className="section section--ivory">
        <div className="container">
          <SectionHeading eyebrow={t('ann.eyebrow')} title={t('ann.latest')} />
          {ann.rows.length ? (
            <div>
              {ann.rows.map((r) => (
                <AnnouncementItem key={r.id} item={r} />
              ))}
            </div>
          ) : (
            <EmptyState title={t('ann.soon')} text={t('ann.soonText')} />
          )}
          <p style={{ marginTop: 28 }}>
            <Link className="link-arrow" to="/announcements">
              {t('ann.viewAll')} <Icon name="arrow" size={18} />
            </Link>
          </p>
        </div>
      </section>

      {/* JOIN CTA */}
      <section className="section section--maroon cta">
        <div className="container">
          <span className="eyebrow" style={{ justifyContent: 'center' }}>{t('join.eyebrow')}</span>
          <h2>{tx(home.ctaTitle)}</h2>
          <p>{tx(home.ctaText)}</p>
          <div className="btn-row">
            <Link className="btn btn--saffron" to="/join">{t('join.cta')}</Link>
            <Link className="btn btn--outline" to="/contact">{t('nav.contact')}</Link>
          </div>
        </div>
      </section>
    </>
  )
}
