import { useEffect, useState } from 'react'
import { useContent } from '../context/ContentContext'

// Displays the owner's ORIGINAL logo exactly as supplied (uploaded in Admin ->
// Logo, or placed at public/logo.png). Only the height is set; width stays
// automatic so proportions are never changed. If no logo exists yet, plain text
// is shown (the logo is never redrawn or imitated).
export default function Logo({ height = 48 }) {
  const { content } = useContent()
  const src = content.site.logo || '/logo.png'
  const [ok, setOk] = useState(true)
  useEffect(() => setOk(true), [src])
  if (!ok) return <span className="logo-fallback">VanshkeHanumanji Team</span>
  return (
    <img
      className="logo-img"
      src={src}
      alt="VanshkeHanumanji Team logo"
      style={{ height }}
      onError={() => setOk(false)}
    />
  )
}
