import { useEffect, useState } from 'react'
import Logo from './Logo'

// Short branded splash on first visit only.
export default function Loader() {
  const [done, setDone] = useState(false)
  const [gone, setGone] = useState(false)

  useEffect(() => {
    const a = setTimeout(() => setDone(true), 1100)
    const b = setTimeout(() => setGone(true), 1800)
    return () => {
      clearTimeout(a)
      clearTimeout(b)
    }
  }, [])

  if (gone) return null
  return (
    <div className={`loader ${done ? 'done' : ''}`} role="status" aria-label="Loading">
      <div className="loader__box">
        <Logo height={96} />
        <div className="loader__bar" />
      </div>
    </div>
  )
}
