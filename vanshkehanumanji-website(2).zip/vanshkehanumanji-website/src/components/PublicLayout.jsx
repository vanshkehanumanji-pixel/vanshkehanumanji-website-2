import { useEffect } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Navbar from './Navbar'
import Footer from './Footer'
import WhatsAppFloat from './WhatsAppFloat'
import Loader from './Loader'
import { useLang } from '../context/LangContext'

export default function PublicLayout() {
  const { pathname } = useLocation()
  const { t } = useLang()

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])

  return (
    <>
      <Loader />
      <a className="skip-link" href="#main">
        {t('nav.skip')}
      </a>
      <Navbar />
      <main id="main" key={pathname} className="page-enter" tabIndex={-1}>
        <Outlet />
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
