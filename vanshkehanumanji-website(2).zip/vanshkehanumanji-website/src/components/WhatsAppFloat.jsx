import { useContent } from '../context/ContentContext'
import { useLang } from '../context/LangContext'
import Icon from './Icon'

export default function WhatsAppFloat() {
  const { content } = useContent()
  const { t } = useLang()
  const url = content.contact.whatsappUrl
  if (!url) return null
  return (
    <a className="wa-float" href={url} target="_blank" rel="noopener noreferrer" aria-label={t('wa.label')}>
      <Icon name="whatsapp" size={28} />
    </a>
  )
}
