import { useLang } from '../context/LangContext'
import { SEVA_CATEGORIES, ANNOUNCEMENT_KINDS } from '../lib/defaults'
import { formatDate, pick } from '../lib/utils'
import { Img } from './ui'
import Icon from './Icon'

const labelOf = (list, id, lang) => {
  const x = list.find((c) => c.id === id)
  return x ? x[lang] || x.en : ''
}

export function SevaCard({ item }) {
  const { lang, t } = useLang()
  return (
    <article className="media-card">
      {item.photo_url && (
        <div className="media-card__img">
          <Img src={item.photo_url} alt={pick(item, 'title', lang)} />
        </div>
      )}
      <div className="media-card__body">
        <span className="tag">{labelOf(SEVA_CATEGORIES, item.category, lang)}</span>
        <h3>{pick(item, 'title', lang)}</h3>
        <p style={{ whiteSpace: 'pre-line' }}>{pick(item, 'description', lang)}</p>
        <div className="meta">
          {item.activity_date && <span>{formatDate(item.activity_date, lang)}</span>}
          {item.location && (
            <span aria-label={t('common.location')}>
              <Icon name="pin" size={14} /> {item.location}
            </span>
          )}
        </div>
      </div>
    </article>
  )
}

export function AnnouncementItem({ item, dark }) {
  const { lang, t } = useLang()
  return (
    <article className="ann">
      <div className="ann__date">
        {formatDate(item.published_at, lang)}
        {item.event_date && (
          <div style={{ fontSize: '0.85rem', fontFamily: 'var(--f-body)', marginTop: 4 }}>
            {t('ann.eventDate')}: {formatDate(item.event_date, lang)}
          </div>
        )}
      </div>
      <div>
        <span className="tag" style={dark ? { color: 'var(--gold)' } : undefined}>
          {labelOf(ANNOUNCEMENT_KINDS, item.kind, lang)}
        </span>
        <h3>{pick(item, 'title', lang)}</h3>
        <p className={dark ? 'muted' : ''} style={{ whiteSpace: 'pre-line', marginBottom: 0 }}>
          {pick(item, 'body', lang)}
        </p>
      </div>
    </article>
  )
}

export function GalleryTile({ item, onOpen }) {
  const { lang, t } = useLang()
  const cap = pick(item, 'caption', lang)
  return (
    <button type="button" className="gallery-tile" onClick={onOpen} aria-label={cap || t('gallery.open')}>
      <img src={item.url} alt={cap} loading="lazy" decoding="async" />
      {cap && <span className="cap">{cap}</span>}
    </button>
  )
}
