import { useEffect, useRef } from 'react'
import { useLang } from '../context/LangContext'
import { pick } from '../lib/utils'

export default function Lightbox({ items, index, onClose, onChange }) {
  const { t, lang } = useLang()
  const closeRef = useRef(null)
  const item = items[index]
  const many = items.length > 1

  useEffect(() => {
    const prevFocus = document.activeElement
    closeRef.current?.focus()
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = ''
      prevFocus?.focus?.()
    }
  }, [])

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowRight' && many) onChange((index + 1) % items.length)
      if (e.key === 'ArrowLeft' && many) onChange((index - 1 + items.length) % items.length)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [index, items.length, many, onChange, onClose])

  if (!item) return null
  const caption = pick(item, 'caption', lang)

  return (
    <div className="lightbox" role="dialog" aria-modal="true" aria-label={caption || 'Photo'} onClick={onClose}>
      <button ref={closeRef} type="button" className="lb-close" aria-label={t('gallery.close')} onClick={onClose}>
        ✕
      </button>
      {many && (
        <button
          type="button"
          className="lb-prev"
          aria-label={t('gallery.prev')}
          onClick={(e) => {
            e.stopPropagation()
            onChange((index - 1 + items.length) % items.length)
          }}
        >
          ‹
        </button>
      )}
      <figure style={{ margin: 0 }} onClick={(e) => e.stopPropagation()}>
        <img src={item.url} alt={caption} />
        {caption && <figcaption className="lightbox__cap">{caption}</figcaption>}
      </figure>
      {many && (
        <button
          type="button"
          className="lb-next"
          aria-label={t('gallery.next')}
          onClick={(e) => {
            e.stopPropagation()
            onChange((index + 1) % items.length)
          }}
        >
          ›
        </button>
      )}
    </div>
  )
}
