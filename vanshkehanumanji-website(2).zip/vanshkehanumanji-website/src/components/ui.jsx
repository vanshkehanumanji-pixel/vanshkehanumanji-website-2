import { useState } from 'react'
import Logo from './Logo'
import Icon from './Icon'
import { useLang } from '../context/LangContext'

export function SectionHeading({ eyebrow, title, children, center }) {
  return (
    <div className={`heading ${center ? 'heading--center' : ''}`}>
      {eyebrow && <span className="eyebrow">{eyebrow}</span>}
      <h2>{title}</h2>
      <div className="ornament" aria-hidden="true"><span /></div>
      {children && <p>{children}</p>}
    </div>
  )
}

export function PageBanner({ eyebrow, title, children }) {
  return (
    <section className="banner">
      <div className="container">
        <span className="eyebrow" style={{ color: 'var(--gold)' }}>{eyebrow}</span>
        <h1>{title}</h1>
        {children && <p>{children}</p>}
      </div>
    </section>
  )
}

export function EmptyState({ title, text }) {
  return (
    <div className="empty">
      <h3>{title}</h3>
      {text && <p>{text}</p>}
    </div>
  )
}

// A framed photograph shown exactly as supplied (cropped by CSS only).
// `fallback`: 'logo' shows the original logo; otherwise a neutral placeholder.
export function FramedPhoto({ src, alt, fallback = 'placeholder' }) {
  const { t } = useLang()
  const [failed, setFailed] = useState(!src)
  return (
    <div className="frame">
      <div className="frame__inner">
        {!failed ? (
          <img className="photo" src={src} alt={alt} onError={() => setFailed(true)} decoding="async" />
        ) : fallback === 'logo' ? (
          <div style={{ padding: 36 }}>
            <Logo height={150} />
          </div>
        ) : (
          <div className="placeholder">
            <div>
              <Icon name="user" size={44} />
              {t('common.photoSoon')}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export function Img({ src, alt = '' }) {
  const [failed, setFailed] = useState(!src)
  if (failed) return null
  return <img src={src} alt={alt} loading="lazy" decoding="async" onError={() => setFailed(true)} />
}

export function Field({ id, label, optional, error, children }) {
  const { t } = useLang()
  return (
    <div className={`field ${error ? 'invalid' : ''}`}>
      <label htmlFor={id}>
        {label} {optional && <span className="opt">({t('join.optional')})</span>}
      </label>
      {children}
      {error && (
        <div className="err" id={`${id}-err`} role="alert">
          {error}
        </div>
      )}
    </div>
  )
}
