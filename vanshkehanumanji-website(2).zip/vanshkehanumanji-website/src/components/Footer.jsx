import { Link } from 'react-router-dom'
import { useLang } from '../context/LangContext'
import { useContent } from '../context/ContentContext'
import Logo from './Logo'
import Icon from './Icon'

const nav = [
  ['/about', 'nav.about'],
  ['/founder', 'nav.founder'],
  ['/team', 'nav.team'],
  ['/seva', 'nav.seva'],
  ['/gallery', 'nav.gallery'],
  ['/announcements', 'nav.announcements'],
  ['/join', 'nav.join'],
  ['/contact', 'nav.contact'],
]

export default function Footer() {
  const { t, tx } = useLang()
  const { content } = useContent()
  const { site, contact, founder } = content

  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div>
          <Logo height={64} />
          <p className="footer__tag">{site.tagline.hi}</p>
          <p style={{ marginBottom: 4 }}>
            {t('footer.founder')}: <strong style={{ color: 'var(--ivory)' }}>{tx(founder.name)}</strong>
          </p>
          <p style={{ margin: 0 }}>{tx(contact.location)}</p>
        </div>

        <div>
          <h4>{t('footer.explore')}</h4>
          <ul>
            {nav.map(([to, key]) => (
              <li key={to}>
                <Link to={to}>{t(key)}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4>{t('footer.connect')}</h4>
          <ul>
            {contact.instagramUrl && (
              <li>
                <a href={contact.instagramUrl} target="_blank" rel="noopener noreferrer">
                  Instagram {contact.instagram}
                </a>
              </li>
            )}
            {contact.whatsappUrl && (
              <li>
                <a href={contact.whatsappUrl} target="_blank" rel="noopener noreferrer">
                  WhatsApp {contact.whatsapp}
                </a>
              </li>
            )}
            {contact.email && (
              <li>
                <a href={`mailto:${contact.email}`}>{contact.email}</a>
              </li>
            )}
            {contact.facebookUrl && (
              <li>
                <a href={contact.facebookUrl} target="_blank" rel="noopener noreferrer">Facebook</a>
              </li>
            )}
            {contact.youtubeUrl && (
              <li>
                <a href={contact.youtubeUrl} target="_blank" rel="noopener noreferrer">YouTube</a>
              </li>
            )}
          </ul>
        </div>
      </div>

      <div className="container footer__bar">
        <span>
          © {new Date().getFullYear()} {site.name}. {t('footer.rights')}
        </span>
        <span className="footer__bless">{site.footerBlessing}</span>
        <span>
          <Link to="/privacy">{t('footer.privacy')}</Link> · <Link to="/terms">{t('footer.terms')}</Link>
        </span>
      </div>
    </footer>
  )
}
