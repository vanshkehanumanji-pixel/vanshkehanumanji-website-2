import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { useLang } from '../context/LangContext'
import Logo from './Logo'
import Icon from './Icon'

const links = [
  ['/', 'nav.home'],
  ['/about', 'nav.about'],
  ['/founder', 'nav.founder'],
  ['/team', 'nav.team'],
  ['/seva', 'nav.seva'],
  ['/gallery', 'nav.gallery'],
  ['/announcements', 'nav.announcements'],
  ['/join', 'nav.join'],
  ['/contact', 'nav.contact'],
]

export default function Navbar() {
  const { t, toggle } = useLang()
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()

  useEffect(() => setOpen(false), [pathname])

  return (
    <header className="nav">
      <div className="container nav__inner">
        <Link to="/" className="nav__brand" aria-label="VanshkeHanumanji Team — Home">
          <Logo height={50} />
        </Link>

        <nav aria-label="Main">
          <ul className={`nav__links ${open ? 'open' : ''}`} id="main-menu">
            {links.map(([to, key]) => (
              <li key={to}>
                <NavLink to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>
                  {t(key)}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className="nav__actions">
          <button type="button" className="lang-btn" onClick={toggle} aria-label={t('lang.switchLabel')}>
            {t('lang.switch')}
          </button>
          <button
            type="button"
            className="burger"
            aria-expanded={open}
            aria-controls="main-menu"
            aria-label={t('nav.menu')}
            onClick={() => setOpen((o) => !o)}
          >
            <Icon name={open ? 'close' : 'menu'} size={22} />
          </button>
        </div>
      </div>
    </header>
  )
}
