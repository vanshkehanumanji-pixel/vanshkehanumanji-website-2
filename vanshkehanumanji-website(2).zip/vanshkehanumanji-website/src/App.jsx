import { lazy, Suspense } from 'react'
import { Route, Routes } from 'react-router-dom'
import PublicLayout from './components/PublicLayout'
import Home from './pages/Home'
import About from './pages/About'
import Founder from './pages/Founder'
import Team from './pages/Team'
import Seva from './pages/Seva'
import Gallery from './pages/Gallery'
import Announcements from './pages/Announcements'
import Join from './pages/Join'
import Contact from './pages/Contact'
import { Privacy, Terms } from './pages/Legal'
import NotFound from './pages/NotFound'

// The admin area is a separate chunk: public visitors never download it.
const AdminApp = lazy(() => import('./pages/admin/AdminApp'))

export default function App() {
  return (
    <Routes>
      <Route element={<PublicLayout />}>
        <Route index element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="founder" element={<Founder />} />
        <Route path="team" element={<Team />} />
        <Route path="seva" element={<Seva />} />
        <Route path="gallery" element={<Gallery />} />
        <Route path="announcements" element={<Announcements />} />
        <Route path="join" element={<Join />} />
        <Route path="contact" element={<Contact />} />
        <Route path="privacy" element={<Privacy />} />
        <Route path="terms" element={<Terms />} />
        <Route path="*" element={<NotFound />} />
      </Route>
      <Route
        path="admin/*"
        element={
          <Suspense fallback={<div style={{ padding: 40 }}>Loading…</div>}>
            <AdminApp />
          </Suspense>
        }
      />
    </Routes>
  )
}
